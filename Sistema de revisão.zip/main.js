const firebaseConfig = {
  apiKey: "AIzaSyD6Qo4FWubTZhzTIfEQSzQBWTKkCtax23M",
  authDomain: "revis-c6c3e.firebaseapp.com",
  projectId: "revis-c6c3e",
  storageBucket: "revis-c6c3e.firebasestorage.app",
  messagingSenderId: "1044121601349",
  appId: "1:1044121601349:web:7e77f36868efb3020baa2c",
  databaseURL: "https://revis-c6c3e-default-rtdb.firebaseio.com"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.database();

let isLogin = true;
let dadosCarregados = [];
let dadosFiltrados = [];
let paginaAtual = 1;
const itensPorPagina = 5;
let ordemAtual = { campo: null, direcao: 'asc' };

// Função global visível para o onclick do HTML
window.toggleAuth = function () {
  isLogin = !isLogin;
  document.getElementById("formTitle").innerText = isLogin ? "Entrar" : "Cadastrar";
  document.getElementById("actionBtn").innerText = isLogin ? "Entrar" : "Cadastrar";
  document.getElementById("toggleMessage").innerHTML = isLogin
    ? 'Ainda não tem cadastro? <a href="#" onclick="toggleAuth()">Cadastrar</a>'
    : 'Já tem cadastro? <a href="#" onclick="toggleAuth()">Entrar</a>';
};

document.getElementById("authForm")?.addEventListener("submit", (e) => {
  e.preventDefault();
  const email = document.getElementById("email").value;
  const senha = document.getElementById("password").value;

  const action = isLogin
    ? auth.signInWithEmailAndPassword(email, senha)
    : auth.createUserWithEmailAndPassword(email, senha);

  action.then(() => window.location.href = "dashboard.html")
    .catch(err => alert("Erro: " + err.message));
});

function logout() {
  auth.signOut().then(() => window.location.href = "index.html");
}

function showToast(mensagem) {
  const toast = document.getElementById("toast");
  if (!toast) return;
  toast.textContent = mensagem;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 3000);
}

function validarFormulario() {
  const materia = document.getElementById("materia");
  const assunto = document.getElementById("assunto");
  const dias = document.getElementById("dias");

  let valido = true;
  [materia, assunto, dias].forEach(campo => {
    const erro = document.getElementById(`${campo.id}-error`);
    if (!campo.value.trim()) {
      erro.textContent = "Campo obrigatório";
      erro.style.display = "block";
      valido = false;
    } else {
      erro.textContent = "";
      erro.style.display = "none";
    }
  });

  return valido;
}

const revisionForm = document.getElementById("revisionForm");
if (revisionForm) {
  revisionForm.addEventListener("submit", (e) => {
    e.preventDefault();
    if (!validarFormulario()) return;

    const materia = document.getElementById("materia").value;
    const assunto = document.getElementById("assunto").value;
    const dias = parseInt(document.getElementById("dias").value);
    const data = new Date();
    data.setDate(data.getDate() + dias);
    const dataFormatada = data.toLocaleDateString('pt-BR').split('/').reverse().join('-');

    const revisao = { materia, assunto, data: dataFormatada };
    const uid = auth.currentUser?.uid;
    if (uid) {
      db.ref("revisoes/" + uid).push(revisao);
      revisionForm.reset();
      showToast("Revisão cadastrada com sucesso!");
    }
  });
}

function renderTabela(dados) {
  const tabelaBody = document.getElementById("tabela-body");
  if (!tabelaBody) return;

  const hoje = new Date().toLocaleDateString('pt-BR').split('/').reverse().join('-');
  const inicio = (paginaAtual - 1) * itensPorPagina;
  const fim = inicio + itensPorPagina;
  const paginados = dados.slice(inicio, fim);
  tabelaBody.innerHTML = "";

  paginados.forEach(({ key, materia, assunto, data }) => {
    const linha = document.createElement("tr");
    if (data < hoje) linha.classList.add("vencida");
    if (data === hoje) linha.classList.add("hoje");

    linha.innerHTML = `
      <td>${materia}</td>
      <td>${assunto}</td>
      <td>${data}</td>
      <td>
        <div class="action-buttons">
          <button onclick="editarRevisao('${key}')"><i class='fas fa-edit'></i></button>
          <button onclick="excluirRevisao('${key}')"><i class='fas fa-trash-alt'></i></button>
        </div>
      </td>
    `;
    tabelaBody.appendChild(linha);
  });

  renderPaginacao(dados);
}

function renderPaginacao(dados) {
  const paginacao = document.getElementById("paginacao");
  if (!paginacao) return;
  const totalPaginas = Math.ceil(dados.length / itensPorPagina);
  paginacao.innerHTML = "";

  for (let i = 1; i <= totalPaginas; i++) {
    const botao = document.createElement("button");
    botao.textContent = i;
    botao.className = (i === paginaAtual) ? "active" : "";
    botao.onclick = () => {
      paginaAtual = i;
      renderTabela(dadosFiltrados);
    };
    paginacao.appendChild(botao);
  }
}

function aplicarFiltro() {
  const termo = document.getElementById("filtro")?.value.toLowerCase() || "";
  dadosFiltrados = dadosCarregados.filter(r =>
    r.materia.toLowerCase().includes(termo) ||
    r.assunto.toLowerCase().includes(termo)
  );
  renderTabela(dadosFiltrados);
}

document.getElementById("filtro")?.addEventListener("input", aplicarFiltro);

document.getElementById("darkModeToggle")?.addEventListener("click", () => {
  document.body.classList.toggle("dark-mode");
  localStorage.setItem("modoEscuro", document.body.classList.contains("dark-mode"));
});

function ordenarTabela(campo) {
  if (ordemAtual.campo === campo) {
    ordemAtual.direcao = ordemAtual.direcao === "asc" ? "desc" : "asc";
  } else {
    ordemAtual.campo = campo;
    ordemAtual.direcao = "asc";
  }

  dadosFiltrados.sort((a, b) => {
    if (a[campo] < b[campo]) return ordemAtual.direcao === "asc" ? -1 : 1;
    if (a[campo] > b[campo]) return ordemAtual.direcao === "asc" ? 1 : -1;
    return 0;
  });

  renderTabela(dadosFiltrados);
}

function editarRevisao(key) {
  const revisao = dadosCarregados.find(r => r.key === key);
  if (!revisao) return;

  document.getElementById("materia").value = revisao.materia;
  document.getElementById("assunto").value = revisao.assunto;
  document.getElementById("dias").value = 0;

  revisionForm.onsubmit = (e) => {
    e.preventDefault();
    const materia = document.getElementById("materia").value;
    const assunto = document.getElementById("assunto").value;
    db.ref("revisoes/" + auth.currentUser.uid + "/" + key).update({ materia, assunto })
      .then(() => {
        showToast("Revisão atualizada.");
        revisionForm.reset();
        revisionForm.onsubmit = defaultSubmitHandler;
      });
  };
}

function excluirRevisao(key) {
  const uid = auth.currentUser.uid;
  if (confirm("Deseja excluir esta revisão?")) {
    db.ref("revisoes/" + uid + "/" + key).remove();
    showToast("Revisão excluída.");
  }
}

function exportarCSV() {
  let csv = "Matéria,Assunto,Data\n";
  dadosFiltrados.forEach(r => {
    csv += `${r.materia},${r.assunto},${r.data}\n`;
  });
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.setAttribute("download", "revisoes.csv");
  link.click();
}

function defaultSubmitHandler(e) {
  e.preventDefault();
  if (!validarFormulario()) return;
  const materia = document.getElementById("materia").value;
  const assunto = document.getElementById("assunto").value;
  const dias = parseInt(document.getElementById("dias").value);
  const data = new Date();
  data.setDate(data.getDate() + dias);
  const dataFormatada = data.toLocaleDateString('pt-BR').split('/').reverse().join('-');

  const revisao = { materia, assunto, data: dataFormatada };
  const uid = auth.currentUser?.uid;
  if (uid) {
    db.ref("revisoes/" + uid).push(revisao);
    revisionForm.reset();
    showToast("Revisão cadastrada com sucesso!");
  }
}

revisionForm.onsubmit = defaultSubmitHandler;

auth.onAuthStateChanged(user => {
  if (user && document.getElementById("alertas")) {
    const uid = user.uid;
    const hoje = new Date().toLocaleDateString('pt-BR').split('/').reverse().join('-');
    const alertasDiv = document.getElementById("alertas");
    db.ref("revisoes/" + uid).on("value", snapshot => {
      alertasDiv.innerHTML = "<h3>Revisões para hoje:</h3>";
      dadosCarregados = [];
      snapshot.forEach(child => {
        const { materia, assunto, data } = child.val();
        dadosCarregados.push({ key: child.key, materia, assunto, data });

        if (data === hoje) {
          alertasDiv.innerHTML += `<p><strong>${materia}</strong> - ${assunto}</p>`;
          const som = new Audio('alerta.mp3');
          som.play().catch(() => {});
          if (window.innerWidth <= 768) {
            alert(`📌 Revisão para hoje: ${materia} - ${assunto}`);
          }
        }
      });

      if (alertasDiv.innerHTML === "<h3>Revisões para hoje:</h3>") {
        alertasDiv.innerHTML += "<p>Nenhuma revisão marcada para hoje.</p>";
      }

      aplicarFiltro();
    });

    const modoEscuroSalvo = localStorage.getItem("modoEscuro") === "true";
    if (modoEscuroSalvo) document.body.classList.add("dark-mode");
  }
});




