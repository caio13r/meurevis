// Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyD6Qo4FWubTZhzTIfEQSzQBWTKkCtax23M",
  authDomain: "revis-c6c3e.firebaseapp.com",
  projectId: "revis-c6c3e",
  storageBucket: "revis-c6c3e.appspot.com",
  messagingSenderId: "1044121601349",
  appId: "1:1044121601349:web:7e77f36868efb3020baa2c",
  databaseURL: "https://revis-c6c3e-default-rtdb.firebaseio.com"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.database();

const form = document.getElementById('flashcardForm');
const container = document.getElementById('cardsContainer');
const filtro = document.getElementById('filtroCard');
const menuMaterias = document.getElementById('menuMaterias');

let flashcards = [];
let uid = null;

// Funções de autocomplete
function atualizarOpcoesMaterias() {
  const materias = [...new Set(flashcards.map(c => c.materia))];
  let datalist = document.getElementById('materiasList');
  if (!datalist) {
    datalist = document.createElement('datalist');
    datalist.id = 'materiasList';
    document.body.appendChild(datalist);
    document.getElementById('materiaCard').setAttribute('list', 'materiasList');
  }
  datalist.innerHTML = materias.map(m => `<option value="${m}">`).join('');
}

function atualizarOpcoesAssuntos() {
  const materia = document.getElementById('materiaCard').value;
  const assuntos = [...new Set(
    flashcards
      .filter(c => c.materia === materia)
      .map(c => c.assunto)
  )];
  let datalist = document.getElementById('assuntosList');
  if (!datalist) {
    datalist = document.createElement('datalist');
    datalist.id = 'assuntosList';
    document.body.appendChild(datalist);
    document.getElementById('assuntoCard').setAttribute('list', 'assuntosList');
  }
  datalist.innerHTML = assuntos.map(a => `<option value="${a}">`).join('');
}

auth.onAuthStateChanged(user => {
  if (user) {
    uid = user.uid;

    db.ref('flashcards/' + uid).on('value', snapshot => {
      flashcards = [];
      snapshot.forEach(child => {
        flashcards.push({ key: child.key, ...child.val() });
      });
      renderizarCards();
      renderizarMenuMaterias();
      atualizarOpcoesMaterias();
    });

    form.addEventListener('submit', e => {
      e.preventDefault();
      const materia = document.getElementById('materiaCard').value.trim();
      const assunto = document.getElementById('assuntoCard')?.value.trim() || 'Geral';
      const icone = document.getElementById('iconeCard')?.value.trim() || "📌";
      const pergunta = document.getElementById('pergunta').value.trim();
      const resposta = document.getElementById('resposta').value.trim();
      if (materia && assunto && pergunta && resposta) {
        db.ref('flashcards/' + uid).push({ materia, assunto, icone, pergunta, resposta });
        form.reset();
        atualizarOpcoesMaterias();
      }
    });

    document.getElementById('materiaCard').addEventListener('input', atualizarOpcoesAssuntos);
    filtro.addEventListener('input', renderizarCards);
  } else {
    window.location.href = "index.html";
  }
});

function renderizarCards() {
  const termo = filtro.value.toLowerCase();
  const cardsFiltrados = flashcards.filter(c => c.materia.toLowerCase().includes(termo));
  container.innerHTML = '';

  const agrupado = {};
  cardsFiltrados.forEach(card => {
    if (!agrupado[card.materia]) agrupado[card.materia] = {};
    if (!agrupado[card.materia][card.assunto]) agrupado[card.materia][card.assunto] = [];
    agrupado[card.materia][card.assunto].push(card);
  });

  for (const materia in agrupado) {
    const blocoMateria = document.createElement('div');
    blocoMateria.innerHTML = `<h2>${materia}</h2>`;

    for (const assunto in agrupado[materia]) {
      const cardsDoAssunto = agrupado[materia][assunto];
      const icone = cardsDoAssunto[0].icone || "📌";

      const blocoAssunto = document.createElement('div');
      blocoAssunto.innerHTML = `<h3>${icone} ${assunto}</h3>`;
      const linha = document.createElement('div');
      linha.className = 'cards';

      cardsDoAssunto.forEach(card => {
        const cardEl = document.createElement('div');
        cardEl.className = 'card';
        cardEl.dataset.key = card.key;

        const cardInner = document.createElement('div');
        cardInner.className = 'card-inner';

        const cardFront = document.createElement('div');
        cardFront.className = 'card-front';

        const cardActions = document.createElement('div');
        cardActions.className = 'card-actions';
        cardActions.innerHTML = `
          <button class="btn-editar" data-key="${card.key}">✏️</button>
          <button class="btn-excluir" data-key="${card.key}">🗑️</button>
        `;

        const cardContent = document.createElement('div');
        cardContent.className = 'card-content';
        cardContent.textContent = card.pergunta;

        cardFront.appendChild(cardActions);
        cardFront.appendChild(cardContent);

        const cardBack = document.createElement('div');
        cardBack.className = 'card-back';
        cardBack.textContent = card.resposta;

        cardInner.appendChild(cardFront);
        cardInner.appendChild(cardBack);
        cardEl.appendChild(cardInner);
        linha.appendChild(cardEl);

        let clickStage = 0;
        cardEl.addEventListener('click', function (e) {
          if (e.target.closest('button')) return;
          clickStage = (clickStage + 1) % 3;
          this.classList.toggle('expanded', clickStage === 1);
          this.classList.toggle('clicked', clickStage === 2);
          if (clickStage === 2) {
            setTimeout(() => {
              this.classList.remove('clicked', 'expanded');
              clickStage = 0;
            }, 7000);
          }
        });
      });

      blocoAssunto.appendChild(linha);
      blocoMateria.appendChild(blocoAssunto);
    }

    container.appendChild(blocoMateria);
  }
}

function renderizarMenuMaterias() {
  const materias = [...new Set(flashcards.map(c => c.materia))];
  menuMaterias.innerHTML = '';
  materias.forEach(materia => {
    const item = document.createElement('li');
    item.textContent = materia;
    item.onclick = () => {
      const target = document.getElementById(`materia-${materia.replace(/\s+/g, '-')}`);
      if (target) target.scrollIntoView({ behavior: 'smooth' });
    };
    menuMaterias.appendChild(item);
  });
}

// Botões de editar e excluir
document.getElementById('cardsContainer').addEventListener('click', function (e) {
  const key = e.target.dataset.key;
  if (e.target.classList.contains('btn-editar')) {
    const card = flashcards.find(c => c.key === key);
    if (!card) return;
    const novaPergunta = prompt("Editar Frente:", card.pergunta);
    const novaResposta = prompt("Editar Verso:", card.resposta);
    const novoAssunto = prompt("Editar Assunto:", card.assunto || "");
    const novoIcone = prompt("Editar Ícone:", card.icone || "📌");
    if (novaPergunta && novaResposta && novoAssunto) {
      db.ref(`flashcards/${uid}/${key}`).update({
        pergunta: novaPergunta,
        resposta: novaResposta,
        assunto: novoAssunto,
        icone: novoIcone
      });
    }
  }
  if (e.target.classList.contains('btn-excluir')) {
    if (confirm("Deseja excluir este card?")) {
      db.ref(`flashcards/${uid}/${key}`).remove();
    }
  }
});

// Menu retrátil e logout
document.addEventListener('DOMContentLoaded', () => {
  const sidebar = document.getElementById('sidebar');
  const toggleBtn = document.getElementById('toggleSidebar');
  if (sidebar && toggleBtn) {
    toggleBtn.addEventListener('click', () => {
      sidebar.classList.toggle('open');
    });
  }

  const logoutBtn = document.getElementById('btnSair');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      auth.signOut().then(() => {
        window.location.href = "index.html";
      });
    });
  }
});
